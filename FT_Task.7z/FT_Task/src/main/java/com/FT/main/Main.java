package com.FT.main;

import java.io.FileInputStream;
import java.io.IOException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.core.Logger;
import org.apache.logging.log4j.core.config.ConfigurationSource;
import org.apache.logging.log4j.core.config.xml.XmlConfiguration;

import lombok.extern.log4j.Log4j2;

@Log4j2
public class Main {

	/**** Main ****/
	public static void main(String[] args) throws IOException {
		init();
		
		run();
	}

	
	private static void run() {
		log.info("Date 13-4-2023  1:15 pm ") ;
	}

	private static void init() throws IOException {
		
		initLog();
		
	
	
	}

	/*
	 * This function opens the required tools
	 */
	private static void openTools() {
		// Open required tools
	}

	private static void initLog() throws IOException {
		ConfigurationSource source = new ConfigurationSource(
				new FileInputStream(System.getProperty("user.dir") + "\\config\\log4j2.xml"));
		XmlConfiguration xmlConfig = new XmlConfiguration(null, source);
		Logger logger = (Logger) LogManager.getLogger();
		logger.getContext().start(xmlConfig);
	}

}
