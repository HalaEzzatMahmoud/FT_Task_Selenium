package com. FTTask.ManagerCase;

import org.sikuli.script.FindFailed;

import com.FTTask.data.LoadedProperties;
import com.FTTask.pages.AddUser;
import com.FTTask.pages.Admin;
import com.FTTask.pages.DeleteUser;
import com.FTTask.pages.Login;

public class RunCase {

	public static void Run() throws FindFailed {
		Login.LoginOrangeHRM(LoadedProperties.userName, LoadedProperties.userName);
		Admin.OpenAdmin();
		int NumOfRecordsBeforeAdd = Admin.getNumberOfRecords();
		AddUser.AddUser("Oezzat", "Oezzat123");
		int NumOfRecordsAfterAdd = Admin.getNumberOfRecords();
		int addDone = NumOfRecordsAfterAdd - NumOfRecordsBeforeAdd;
		if(addDone>0) {
			System.out.println("New User added Succesfully");
			DeleteUser.selectUserByUsername("Oezzat");
			DeleteUser.deleteSelected();
		}else {
			System.out.println("Add New User added Failed");
		}
		
		
		
	}
}
