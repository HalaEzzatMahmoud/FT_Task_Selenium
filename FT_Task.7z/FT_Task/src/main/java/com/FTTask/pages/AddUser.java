package com.FTTask.pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.sikuli.script.FindFailed;

import com.FTTask.util.Driver;

public class AddUser {

	public static void AddUser(String userName, String password) throws FindFailed {

		Driver.getInstance().findElement(By.xpath("//*[@id=\"app\"]/div[1]/div[2]/div[2]/div/div[2]/div[1]/button"))
				.click();

		Driver.getInstance()
				.findElement(By.xpath("//label[text()='User Role']/following::div[@class='oxd-select-wrapper']"))
				.click();
		Driver.getInstance().findElement(By.xpath("//div[@role='listbox']//span[text()='Admin']")).click();

		Driver.getInstance().findElement(By.xpath("//input[@placeholder='Type for hints...']"))
				.sendKeys("Ranga  Akunuri");
		Driver.getInstance().findElement(By.xpath("//span[text()='Ranga  Akunuri']")).click();

		Driver.getInstance().findElement(By.xpath("//label[text()='Username']/following::input")).sendKeys(userName);

		Driver.getInstance()
				.findElement(By.xpath("//label[text()='Status']/following::div[@class='oxd-select-wrapper']")).click();
		Driver.getInstance().findElement(By.xpath("//div[@role='listbox']//span[text()='Enabled']")).click();

		Driver.getInstance().findElement(By.xpath("//label[text()='Password']/following::input")).sendKeys(password);

		Driver.getInstance().findElement(By.xpath("//label[text()='Confirm Password']/following::input"))
				.sendKeys("Oezzat123");

		Driver.getInstance().findElement(By.xpath("//button[@type='submit' and contains(., 'Save')]")).click();

	}



}
