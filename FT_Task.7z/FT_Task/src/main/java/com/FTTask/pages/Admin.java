package com.FTTask.pages;

import org.openqa.selenium.By;
import org.sikuli.script.FindFailed;

import com.FTTask.util.Driver;

public class Admin {
	public static void OpenAdmin() throws FindFailed {

		Driver.getInstance()
				.findElement(By.xpath("//a[@href='/web/index.php/admin/viewAdminModule']/span[text()='Admin']"))
				.click();


	}

	public static int getNumberOfRecords() {
		String recordCountText = Driver.getInstance().findElement(By.xpath("//div[@class='oxd-text oxd-text--span']"))
				.getText();
		String[] spliterRecordCountText = recordCountText.split(" ");
		int recordCount = Integer.parseInt(spliterRecordCountText[0]);
		return recordCount;
	}
	
}
