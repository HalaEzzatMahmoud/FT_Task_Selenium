package com.FTTask.util;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Proxy;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;

import lombok.experimental.UtilityClass;

@UtilityClass
public class Driver {
	public WebDriver DRIVER;

	public boolean INCOGNITO = false;

	public WebDriver getInstance() {
		if (DRIVER == null) {
			if (Config.get("browserType").equals("firefox"))
				DRIVER = getNewFirefoxDriver();
			else
				DRIVER = getNewChromeDriver();
		}
		DRIVER.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		DRIVER.manage().timeouts().pageLoadTimeout(60, TimeUnit.SECONDS);
		DRIVER.manage().window().maximize();
		return DRIVER;
	}

	public FirefoxDriver getNewFirefoxDriver() {
		System.setProperty("webdriver.gecko.driver", ".\\drivers\\geckodriver.exe");
		return new FirefoxDriver();
	}

	public ChromeDriver getNewChromeDriver() {
		System.setProperty("webdriver.chrome.driver", ".\\drivers\\chromedriver.exe");
		ChromeOptions options = new ChromeOptions();
		if (INCOGNITO) {
			options.addArguments("--incognito");
			// DesiredCapabilities capabilities = DesiredCapabilities.chrome();
			// capabilities.setCapability(ChromeOptions.CAPABILITY, options);
			return new ChromeDriver(options);
		}
		if (Config.get("proxy") != null) {
			Proxy proxy = new Proxy();
			proxy.setProxyAutoconfigUrl(Config.get("proxy"));
			options.setProxy(proxy);
			// options.addArguments("--proxy-pac-url=" + Config.get("proxy"));
			String downloadFilepath = "C:\\AutomationDownload";
			File f = new File(downloadFilepath);
			if (!f.exists()) {
				f.mkdirs();
			}
			Map<String, Object> chromePrefs = new HashMap<String, Object>();
			chromePrefs.put("profile.default_content_settings.popups", 0);
			chromePrefs.put("download.default_directory", downloadFilepath);
			options.setExperimentalOption("prefs", chromePrefs);
		}
		return new ChromeDriver(options);
	}

	public List<String> openTwoTabs() {
		Driver.getInstance().getWindowHandle();
		((JavascriptExecutor) Driver.getInstance()).executeScript("window.open()");
		return new ArrayList<String>(Driver.getInstance().getWindowHandles());
	}
}
